// Calculates total price of stock

function calculateTotal(){
  var form = document.forms["new_user_transaction"];
  var qty = form.elements["stock_id"].value;
}
;
